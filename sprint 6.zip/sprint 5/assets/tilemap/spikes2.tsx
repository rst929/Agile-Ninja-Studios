<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="spikes2" tilewidth="155" tileheight="100" tilecount="1" columns="1">
 <image source="../../../sprint 5/assets/tilemap/spikes2.png" width="155" height="100"/>
</tileset>
