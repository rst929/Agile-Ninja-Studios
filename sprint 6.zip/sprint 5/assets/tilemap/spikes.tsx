<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="spikes" tilewidth="31" tileheight="20" tilecount="1" columns="1">
 <image source="../../../sprint 5/assets/tilemap/Spikes.png" width="31" height="20"/>
</tileset>
