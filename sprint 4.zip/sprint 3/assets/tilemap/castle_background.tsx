<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="castle_background" tilewidth="32" tileheight="32" tilecount="234" columns="18">
 <image source="castle_background_v2.png" width="592" height="426"/>
</tileset>
