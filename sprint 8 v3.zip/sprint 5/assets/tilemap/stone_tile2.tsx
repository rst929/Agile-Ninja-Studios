<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="stone_tile2" tilewidth="32" tileheight="32" tilecount="1" columns="1">
 <image source="stone_tile2.png" width="32" height="32"/>
</tileset>
