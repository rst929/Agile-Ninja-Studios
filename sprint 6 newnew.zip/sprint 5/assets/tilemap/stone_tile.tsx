<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="stone_tile" tilewidth="32" tileheight="32" tilecount="64" columns="8">
 <image source="stone_tile.png" width="256" height="256"/>
</tileset>
